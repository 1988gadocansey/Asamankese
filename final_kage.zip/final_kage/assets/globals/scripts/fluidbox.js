var FluidBox = {

	createFluidBox: function () {
		$('[data-fluidbox]').fluidbox();
	},

	init: function () {
		this.createFluidBox();
	}
}




